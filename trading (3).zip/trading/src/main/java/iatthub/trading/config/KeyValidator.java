package iatthub.trading.config;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class KeyValidator {

    @Value("${api.access.key}")
    private  String VALID_KEY; //

    public boolean validate(String key) {
        if (!VALID_KEY.equals(key)) {
            throw new IllegalArgumentException("Invalid access key");
        }
        else {
            return true;
        }



    }
}



