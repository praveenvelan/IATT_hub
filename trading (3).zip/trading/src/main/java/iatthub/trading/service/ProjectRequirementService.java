package iatthub.trading.service;
import iatthub.trading.config.KeyValidator;
import iatthub.trading.model.ProjectRequirement;
import iatthub.trading.repository.ProjectRequirementRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ProjectRequirementService {

    @Autowired
    private ProjectRequirementRepository repo;

    @Autowired
    private KeyValidator keyValidator;

    public ProjectRequirement createProject(ProjectRequirement p, String key) {
        try {
            keyValidator.validate(key);
             if (repo.existsByEmail(p.getEmail())) {
                throw new IllegalArgumentException("Email already exists");
             }
            if (repo.existsByMobileNumber(p.getMobileNumber())) {
                throw new IllegalArgumentException("Phone number already exists");
             }
             return repo.save(p);
        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("An unexpected error occurred while saving contact");
        }
    }

    public void deleteProject(Long id, String key) {
        keyValidator.validate(key);
        if (!repo.existsById(id)) {
            throw new RuntimeException("project does not exist");
        }
        repo.deleteById(id);
    }

    public List<ProjectRequirement> getAllProjects(String key) {
        if (keyValidator.validate(key)) {
            return repo.findAll();
        }
        throw new RuntimeException("Invalid API Key");
    }

    public ProjectRequirement getProjectById(Long id, String key) {
        if (keyValidator.validate(key)) {
            return repo.findById(id)
                    .orElseThrow(() -> new IllegalArgumentException("Project with ID " + id + " not found"));
        }
        throw new RuntimeException("Invalid API Key");
    }
    public ProjectRequirement updateProject(Long id, ProjectRequirement updated, String key) {
        if (keyValidator.validate(key)) {
            return repo.findById(id).map(existing -> {
                existing.setFullName(updated.getFullName());
                existing.setMobileNumber(updated.getMobileNumber());
                existing.setEmail(updated.getEmail());
                existing.setProjectType(updated.getProjectType());
                existing.setTargetPlatforms(updated.getTargetPlatforms());
                existing.setBudgetRange(updated.getBudgetRange());
                existing.setProjectTimeline(updated.getProjectTimeline());
                existing.setDetailedRequirements(updated.getDetailedRequirements());
                existing.setAdditionalInformation(updated.getAdditionalInformation());
                return repo.save(existing);
            }).orElseThrow(() -> new IllegalArgumentException("Project with ID " + id + " not found"));
        } else {
            throw new RuntimeException("Invalid API Key");
        }
    }
}

