package iatthub.trading.service;
import iatthub.trading.config.KeyValidator;
import iatthub.trading.model.Contact;
import iatthub.trading.repository.ContactRepository;
import iatthub.trading.utility.WatiTemplateSender;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ContactService {

    @Autowired
    private ContactRepository cr;

    @Autowired
    private KeyValidator keyValidator;

    @Autowired
    private WatiTemplateSender watiTemplateSender;

    public Contact saveContact(Contact c,String key) {
        try {
            keyValidator.validate(key);
            if (cr.existsByEmail(c.getEmail())) {
                throw new IllegalArgumentException("Email already exists");
            }
            if (cr.existsByPhone(c.getPhone())) {
                throw new IllegalArgumentException("Phone number already exists");
            }
            return cr.save(c);
           // ✅ Send WhatsApp message using only name & phone
//            Contact saved = cr.save(c);
//            watiTemplateSender.sendWelcomeTemplate(saved);

        } catch (IllegalArgumentException e) {
            throw e;
        } catch (Exception e) {
            throw new RuntimeException("An unexpected error occurred while saving contact");
        }
    }

    public void deleteContact(Long id, String key) {
        keyValidator.validate(key);
        if (!cr.existsById(id)) {
            throw new RuntimeException("contact does not exist");
        }
        cr.deleteById(id);

    }

    public List<Contact> getAllContacts(String key) {
        if (keyValidator.validate(key)) {
            return cr.findAll();
        }
        throw new RuntimeException("Invalid API Key");
    }


    public Contact getContactById(Long id, String key) {
        if (keyValidator.validate(key)) {
            return cr.findById(id)
                    .orElseThrow(() -> new RuntimeException("Contact not found with ID: " + id));
        }
        throw new RuntimeException("Invalid API Key");
    }

    public Contact updateContact(Long id, Contact upd, String key) {
        if (keyValidator.validate(key)) {
            return cr.findById(id).map(existing -> {
                existing.setFullName(upd.getFullName());
                existing.setEmail(upd.getEmail());
                existing.setPhone(upd.getPhone());
                existing.setSubject(upd.getSubject());
                existing.setMessage(upd.getMessage());
                return cr.save(existing);
            }).orElseThrow(() -> new IllegalArgumentException("Contact with ID " + id + " not found"));
        } else {
            throw new RuntimeException("Invalid API Key");
        }
    }

}
