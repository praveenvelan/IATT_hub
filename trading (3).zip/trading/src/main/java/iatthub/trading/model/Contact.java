package iatthub.trading.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;


@Entity
@Table(
        name = "contact_us",
        uniqueConstraints = {
                @UniqueConstraint(columnNames = "email"),
                @UniqueConstraint(columnNames = "phone")
        }
)
@Data
public class Contact {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        @NotBlank(message = "Full Name is required")
        private String fullName;

        @NotBlank(message = "Email Address is required")
        @Column(unique = true)
        @Email(message = "Invalid email format")
        private String email;

        @NotNull(message = "Phone Number is required")
        @Column(unique = true)
        private Long phone;

        @NotBlank(message = "Subject is required")

        private String subject;

        @NotBlank(message = "Message is required")

        private String message;
    }


