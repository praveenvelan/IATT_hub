package iatthub.trading.model;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.util.List;

@Entity
@Data
public class ProjectRequirement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank(message = "Fullname Address is required")
    private String fullName;

    @NotNull(message = "Phone Number is required")
    @Column(unique = true)
    private String mobileNumber;

    @Column(unique = true)
    @NotBlank(message = "Email Address is required")
    @Email(message = "Invalid email format")
    private String email;

    private String projectType;


    private List<String> targetPlatforms;

    private String budgetRange;
    private String projectTimeline;
    @NotBlank(message = "detailedRequirements Address is required")

    private String detailedRequirements;


    private String additionalInformation;
}