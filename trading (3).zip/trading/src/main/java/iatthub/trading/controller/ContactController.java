package iatthub.trading.controller;
import iatthub.trading.model.Contact;
import iatthub.trading.service.ContactService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/contact")
public class ContactController {

    @Autowired
    private ContactService cs;

    @PostMapping("/post")
    public ResponseEntity<?> createContact(@Valid @RequestBody Contact c1, @RequestHeader("X-API-KEY") String key) {
        Contact saved = cs.saveContact(c1,key);
        return new ResponseEntity<>(saved, HttpStatus.CREATED);
    }

    @GetMapping("/get/{id}")
    public ResponseEntity<?> getContactById(@PathVariable Long id, @RequestHeader("X-API-KEY") String key) {
        Contact contact = cs.getContactById(id, key);
        return new ResponseEntity<>(contact, HttpStatus.OK);
    }

    @GetMapping("/get")
    public ResponseEntity<?> getAllContacts(@RequestHeader("X-API-KEY") String key) {
        List<Contact> contacts = cs.getAllContacts(key);
        return new ResponseEntity<>(contacts, HttpStatus.OK);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteContact(@PathVariable Long id, @RequestHeader("X-API-KEY") String key) {
        cs.deleteContact(id, key);
        return new ResponseEntity<>("data deleted successfully",HttpStatus.OK);

    }

    @PutMapping("/put/{id}")
    public ResponseEntity<?> updateContact(@PathVariable Long id, @Valid @RequestBody Contact upd, @RequestHeader("X-API-KEY") String key) {
        Contact updated = cs.updateContact(id, upd, key);
        return new ResponseEntity<>(updated, HttpStatus.OK);
    }
}




