package iatthub.trading.controller;
import iatthub.trading.model.Contact;
import iatthub.trading.model.ProjectRequirement;
import iatthub.trading.service.ProjectRequirementService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/project")
public class ProjectRequirementController {

    @Autowired
    private ProjectRequirementService service;


    @PostMapping("/post")
    public ResponseEntity<?> create(@Valid @RequestBody ProjectRequirement p, @RequestHeader("X-API-KEY") String key) {
        ProjectRequirement saved = service.createProject(p, key);
        return new ResponseEntity<>(saved, HttpStatus.CREATED);
    }

    @PutMapping("/put/{id}")
    public ResponseEntity<?> updateProject(@PathVariable Long id, @Valid @RequestBody ProjectRequirement updated, @RequestHeader("X-API-KEY") String key) {
        ProjectRequirement updatedProject = service.updateProject(id, updated, key);
        return new ResponseEntity<>(updatedProject, HttpStatus.OK);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<?> deleteProject(@PathVariable Long id, @RequestHeader("X-API-KEY") String key) {
        service.deleteProject(id, key);
        return new ResponseEntity<>("data deleted successfully", HttpStatus.OK);

    }

    @GetMapping("/get")
    public ResponseEntity<?> getAll(@RequestHeader("X-API-KEY") String key) {
        List<ProjectRequirement> req =service.getAllProjects(key);
        return new ResponseEntity<>(req, HttpStatus.OK);
    }

    @GetMapping("/get/{id}")
    public ResponseEntity<?> getById(@PathVariable Long id, @RequestHeader("X-API-KEY") String key) {
        ProjectRequirement req = service.getProjectById(id, key);
        return new ResponseEntity<>(req ,HttpStatus.OK);
    }
}