package iatthub.trading.repository;

import iatthub.trading.model.ProjectRequirement;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProjectRequirementRepository extends JpaRepository<ProjectRequirement, Long> {
    boolean existsByMobileNumber(String mobileNumber);
    boolean existsByEmail(String email);

}