package iatthub.trading.utility;

import iatthub.trading.model.Contact;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Component
public class WatiTemplateSender {

    @Value("${wati.api.url}")
    private String apiUrl;

    @Value("${wati.api.key}")
    private String apiKey;

    @Value("${wati.template.name}")
    private String templateName;

    @Value("${wati.template.language}")
    private String languageCode;

    public void sendWelcomeTemplate(Contact contact) {
        try {
            RestTemplate restTemplate = new RestTemplate();

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", "Bearer " + apiKey);

            // Build request body
            Map<String, Object> body = new HashMap<>();
            body.put("number", "91" + contact.getPhone()); // Add country code
            body.put("template_name", templateName);
            body.put("broadcast_name", "welcome_test");

            List<Map<String, String>> params = new ArrayList<>();
            Map<String, String> paramEntry = new HashMap<>();
            paramEntry.put("paramName", "name");
            paramEntry.put("paramValue", contact.getFullName());
            params.add(paramEntry);

            body.put("params", params);

            HttpEntity<Map<String, Object>> request = new HttpEntity<>(body, headers);
            ResponseEntity<String> response = restTemplate.exchange(apiUrl, HttpMethod.POST, request, String.class);

            if (response.getStatusCode().is2xxSuccessful()) {
                System.out.println("✅ WATI message sent successfully.");
            } else {
                System.out.println("❌ Failed to send WATI message: " + response.getBody());
            }

        } catch (Exception e) {
            System.out.println("🔥 Error sending WATI message: " + e.getMessage());
        }
    }
}
